<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<?php
include './config/database.php';

//fetch data from database using id
if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
    $query = "SELECT * FROM content WHERE id =$id";
    $result = mysqli_query($connection, $query);
    $content = mysqli_fetch_assoc($result);
} else {
    header('location: ' . ROOT_URL);
    die();
}
?>
    <section class="form_content">
        <div class="container form_content_container">
            <h4>Edit Content</h4>
            <?php if (isset($_SESSION['edit-content'])): ?>
            <div class="alert_message error">
                <p>
                <?= $_SESSION['edit-content'];
                unset($_SESSION['edit-content']);
                ?>
                </p>
            </div>
        <?php endif ?>
            <form action="edit-content-logic.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="previous_first_content_image" value="<?= $content['first_content_image'] ?>">
                <input type="hidden" name="previous_second_content_image" value="<?= $content['second_content_image'] ?>">
                <input type="hidden" name="previous_third_content_image" value="<?= $content['third_content_image'] ?>">
                <input type="hidden" name="id" value="<?= $id ?>">
                <input type="text" name="title" placeholder="title" value="<?= $content['title'] ?>">
                <input type="text" name="description" placeholder="description" value="<?= $content['description'] ?>">
                <div class="form_control">
                    <label for="first_content_image">First Image</label>
                    <input type="file" name="first_content_image" id="first_content_image">
                </div>
                <div class="form_control">
                    <label for="second_content_image">second Image</label>
                    <input type="file" name="second_content_image" id="second_content_image">
                </div>
                <div class="form_control">
                    <label for="third_content_image">third Image</label>
                    <input type="file" name="third_content_image" id="third_content_image">
                </div>
                <button type="submit" name="submit" class="btn">submit</button>
            </form>
        </div>
    </section>
</body>

</html>