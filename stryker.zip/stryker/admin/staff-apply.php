<?php 
require 'config/database.php';

$query = "SELECT * FROM applications ORDER BY id desc";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <section class="staff">
        <?php if (isset($_SESSION['edit-content-success'])) : ?>
            <div class="alert_message success">
                <p>
                    <?= $_SESSION['edit-content-success'];
                    unset($_SESSION['edit-content-success']);
                    ?>
                </p>
            </div>
            <?php endif ?>
        <div class="container staff_container">
            <aside>
                <ul>
                    <li>
                        <a href="manage-content.php" >
                            <h4>manage-content</h4>
                        </a>    
                    </li>
                    <li>
                        <a href="staff-apply.php" class="active">
                            <h4>staff application</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                </ul>
            </aside>
            <main>
                <table>
                    <thead>
                        <tr>
                            <th>username</th>
                            <th>name</th>
                            <th>email</th>
                            <th>detail</th>
                            <th>reply</th>
                            <th>view</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($applications = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= $applications['username'] ?></td>
                            <td><?= $applications['name'] ?></td>
                            <td><?= $applications['email'] ?></td>
                            <td><?= $applications['detail'] ?></td>
                            <td><a href="reply-staff-apply.php?id=<?= $applications['id']?>" class="btn sm">edit</a></td>
                            <td><a href="delete-content.php" class="btn sm danger">delete</a></td>
                        </tr>
                        <?php endwhile ?>
                    </tbody>
                </table>
            </main>
        </div>
    </section>
</body>

</html>