<?php 
require 'config/database.php';

$query = "SELECT * FROM content ORDER BY id desc";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <section class="staff">
        <?php if (isset($_SESSION['edit-content-success'])) : ?>
            <div class="alert_message success">
                <p>
                    <?= $_SESSION['edit-content-success'];
                    unset($_SESSION['edit-content-success']);
                    ?>
                </p>
            </div>
            <?php endif ?>
        <div class="container staff_container">
            <aside>
                <ul>
                    <li>
                        <a href="manage-content.php" class="active">
                            <h4>manage-content</h4>
                        </a>    
                    </li>
                    <li>
                        <a href="staff-apply.php">
                            <h4>staff application</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                    <li>
                        <a href="manage-content.php">
                            <h4>manage-content</h4>
                        </a>
                    </li>
                </ul>
            </aside>
            <main>
                <table>
                    <thead>
                        <tr>
                            <th>title</th>
                            <th>description</th>
                            <th>edit</th>
                            <th>delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($content = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= $content['title'] ?></td>
                            <td><?= $content['description'] ?></td>
                            <td><a href="edit-content.php?id=<?= $content['id']?>" class="btn sm">edit</a></td>
                            <td><a href="delete-content.php" class="btn sm danger">delete</a></td>
                        </tr>
                        <?php endwhile ?>
                    </tbody>
                </table>
            </main>
        </div>
    </section>
</body>

</html>