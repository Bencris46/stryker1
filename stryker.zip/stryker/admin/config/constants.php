<?php
session_start();
define('ROOT_URL', 'http://localhost/stryker/');
define('DB_HOST', 'localhost');
define('DB_USER', 'bencris');
define('DB_PASS', 'admin@1234');
define('DB_NAME', 'stryker');
