<?php
require './config/database.php';

if (isset($_POST['submit'])) {
    //get updated form data
    $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
    $previous_first_content_image = filter_var($_POST['previous_first_content_image'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $previous_second_content_image = filter_var($_POST['previous_second_content_image'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $previous_third_content_image = filter_var($_POST['previous_third_content_image'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $title = filter_var($_POST['title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $description = filter_var($_POST['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $first_content_image = $_FILES['first_content_image'];
    $second_content_image = $_FILES['second_content_image'];
    $third_content_image = $_FILES['third_content_image'];

    //verify wether every input are entered
    if (!$title) {
        $_SESSION['edit-content'] = "Please enter title";
    } elseif (!$description) {
        $_SESSION['edit-content'] = "Please enter description";
    } else {
        if ($first_content_image['name']) {
            $previous_first_content_image_path = '../assets/img/products/' . $previous_first_content_image;
            if ($previous_first_content_image_path) {
                unlink($previous_first_content_image_path);
            }
            //work on uploaded content image
            //rename
            $time = time(); // make each image upload unique using current timestamp
            $first_content_image_name = $time . $first_content_image['name'];
            $first_content_image_tmp_name = $first_content_image['tmp_name'];
            $first_content_image_destination_path = '../assets/img/products/' . $first_content_image_name;

            //make sure file is an image
            $allowed_files = ['png', 'jpg', 'jpeg', 'gif'];
            $extention = explode('.', $first_content_image_name);
            $extention = end($extention);
            if (in_array($extention, $allowed_files)) {
                if ($first_content_image['size'] < 3_000_000) {
                    //make sure image size is not too big. (3mb)
                    move_uploaded_file($first_content_image_tmp_name, $first_content_image_destination_path);
                } else {
                    $_SESSION['edit-content'] = "image size is too big. Should be less than 3mb.";
                }
            } else {
                $_SESSION['edit-content'] = "File should be png, jpg, jpeg.";
            }
        }if ($second_content_image['name']) {
            $previous_second_content_image_path = '../assets/img/products/' . $previous_second_content_image;
            if ($previous_second_content_image_path) {
                unlink($previous_second_content_image_path);
            }

            //work on uploaded content image
            $time = time();
            $second_content_image_name = $time . $second_content_image['name'];
            $second_content_image_tmp_name = $second_content_image['tmp_name'];
            $second_content_image_destination_path = '../assets/img/products/' . $second_content_image_name;

            //make sure file is an image
            $allowed_files = ['png', 'jpg', 'jpeg', 'gif'];
            $extention = explode('.', $second_content_image_name);
            $extention = end($extention);
            if (in_array($extention, $allowed_files)) {
                if ($second_content_image['size'] < 3_000_000) {
                    //make sure image size is not too big. (3mb)
                    move_uploaded_file($second_content_image_tmp_name, $second_content_image_destination_path);
                } else {
                    $_SESSION['edit-content'] = "image size is too big. Should be less than 3mb.";
                }
            } else {
                $_SESSION['edit-content'] = "File should be png, jpg, jpeg.";
            }
        }if ($third_content_image['name']) {
            $previous_third_content_image_path = '../assets/img/products/' . $previous_third_content_image;
            if ($previous_third_content_image_path) {
                unlink($previous_third_content_image_path);
            }

            //work on uploaded content image
            $time = time();
            $third_content_image_name = $time . $third_content_image['name'];
            $third_content_image_tmp_name = $third_content_image['tmp_name'];
            $third_content_image_destination_path = ROOT_URL . '../assets/img/products/' . $third_content_image_name;

            //make sure file is an image
            $allowed_files = ['png', 'jpg', 'jpeg', 'gif'];
            $extention = explode('.', $third_content_image_name);
            $extention = end($extention);
            if (in_array($extention, $allowed_files)) {
                if ($third_content_image['size'] < 3_000_000) {
                    //make sure image size is not too big. (3mb)
                    move_uploaded_file($third_content_image_tmp_name, $third_content_image_destination_path);
                } else {
                    $_SESSION['edit-content'] = "image size is too big. Should be less than 3mb.";
                }
            } else {
                $_SESSION['edit-content'] = "File should be png, jpg, jpeg.";
            }
        }
    }
    if (isset($_SESSION['edit-content'])) {
        $_SESSION['edit-content-data'] = $_POST;
        header('location: ' . ROOT_URL . 'admin/edit-content.php?id=' . $id);
        die();
    } else {
        //set first_content_image name if a new one was uploaded, else keep old first_content_image name
        $first_content_image_to_insert = $first_content_image_name ?? $previous_first_content_image;
        $second_content_image_to_insert = $second_content_image_name ?? $previous_second_content_image;
        $third_content_image_to_insert = $third_content_image_name ?? $previous_third_content_image;

        //update user
        $query = "UPDATE content SET title='$title', description = '$description', first_content_image='$first_content_image_to_insert', second_content_image='$second_content_image_to_insert', third_content_image='$third_content_image_to_insert' WHERE id=$id LIMIT 1";
        $result = mysqli_query($connection, $query);
    }
    if (!mysqli_errno($connection)) {
        $_SESSION['edit-content-success'] = "content id = $id edited successfully";
        header('location: ' . ROOT_URL . 'admin/manage-content.php');
        die();
    }

} else {
    header('location: ' . ROOT_URL . 'admin/manage-content.php');
    die();
}
