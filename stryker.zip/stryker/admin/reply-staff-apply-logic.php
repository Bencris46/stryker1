<?php
require 'config/database.php';
