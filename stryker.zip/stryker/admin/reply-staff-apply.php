<?php 
require 'config/database.php';

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
    $query = "SELECT * FROM applications WHERE id = $id";
    $result = mysqli_query($connection, $query);
    $application = mysqli_fetch_assoc($result);
}
else {
    header('location: ' . ROOT_URL . 'admin/staff-apply.php');
    die();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Pricing - Brand</title>
    <meta name="description"
        content="TownyGamingMC is a brand new upcoming space themed Minecraft server. We aim to offer a safe, welcoming &amp; secure environment for you all. I hope you consider joining our Minecraft server!">
    <meta property="og:image" content="https://townygamingmc.cc/assets/img/stryker.png">
    <meta name="twitter:image" content="https://townygamingmc.cc/assets/img/stryker.png">

    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Inter:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alfa+Slab+One&amp;display=swap">
</head>

<body>
    <!-- Start: Navbar Centered Links -->
    <nav class="navbar navbar-dark navbar-expand-md sticky-top navbar-shrink py-3" id="mainNav"
        style="background: rgb(45, 44, 56);">
        <div class="container"><a class="navbar-brand d-flex align-items-center" href="../index.html"><img
                    src="assets/img/stryker.png" style="width: 100px;height: 80px;"></a><button
                data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span
                    class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="https://map.townygamingmc.cc" target="_blank">Map</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="https://store.townygamingmc.cc"
                            target="_blank">Store</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link active" href="staff.html">Staff</a></li>
                    <li class="nav-item"><a class="nav-link" href="rules.html">Rules</a></li>
                </ul><a class="btn btn-primary shadow" role="button" href=" https://discord.gg/FG3Yh7dGpU"
                    target="_blank">Join Us</a>
            </div>
        </div>
    </nav><!-- End: Navbar Centered Links -->
    <section class="py-5 d-flex align-items-center justify-content-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xl-6 text-center mx-auto">
                    <p class="fw-bold text-success mb-2">Apply for staff</p>
                    <h2 class="fw-bold">Fill in the form below</h2>

                    <form class="p-3 p-xl-4" action="#" method="post">
                        <!-- Start: Success Example -->
                            <input type="hidden" id="to-1" name="to"
                                placeholder="to" value="<?= $application['email'] ?>"></input>
                        <div class="mb-3">
                            <textarea class="form-control" id="subject-1" name="subject" rows="2"
                                placeholder="subject"></textarea>
                        </div>
                        <div class="mb-3">
                            <textarea class="form-control" id="body-1" name="body" rows="6"
                                placeholder="body"></textarea>
                        </div>
                        <div>
                            <button class="btn btn-primary shadow d-block w-100" name="submit" type="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark">
        <div class="container py-4 py-lg-5">
            <div class="text-muted d-flex justify-content-between align-items-center pt-3">
                <p class="mb-0">Copyright © 2023 TownyGamingMC Discord</p>
                <p class="mb-0" style="font-size: 11px;">Made By&nbsp;<a href="https://aetherisme.xyz"
                        target="_blank">Aether</a></p>
                <p class="mb-0" style="font-size: 11px;">Modified By&nbsp;<a href="https://bencrissmp.tk"
                        target="_blank">Bencris</a></p>
            </div>
        </div>
    </footer><!-- End: Footer Multi Column -->
    <script src="main.js"></script>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/js/bold-and-dark.js"></script>
</body>

</html>